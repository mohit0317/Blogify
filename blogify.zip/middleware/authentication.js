const { validateToken } = require("../services/authentication");

function checkforAuthenticationCookie(cookieName) {
    return (req, res, next) => {
        // console.log('Checking for authentication cookie:', cookieName);

        const tokenCookieValue = req.cookies?.[cookieName];
        // console.log('Token cookie value:', tokenCookieValue);

        if (!tokenCookieValue) {
            console.log('Token not found');
            return next(); // Proceed to the next middleware or route handler
        }

        try {
            const userPayload = validateToken(tokenCookieValue);
            req.user = userPayload;
        } catch (error) {
            console.error('Invalid token:', error);
        }

        console.log('Proceeding to the next middleware or route handler');
        next(); // Proceed to the next middleware or route handler
    };
}

module.exports = {
    checkforAuthenticationCookie
};
