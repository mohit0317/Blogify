require('dotenv').config();


const express = require("express");
const ejs = require("ejs");
const path = require("path");
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");


const userRouter = require("./router/user");
const blogRouter = require("./router/blog");
const { checkforAuthenticationCookie } = require("./middleware/authentication");
const Blog = require("./model/blog");

const app = express();
const PORT = process.env.PORT || 8000;

mongoose
  .connect(
    process.env.MONGO_URL
  )
  .then((res) => {
    console.log("Mongodb Connected");
  })
  .catch((error) => console.log("Mongodb failed to connect", error));

app.set("view engine", "ejs");
app.set("views", path.resolve("./views"));

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(cookieParser());
app.use(checkforAuthenticationCookie("token"));
app.use(express.static(path.join(__dirname, 'public')));

app.get("/", async (req, res) => {
  const alllBlogs = await Blog.find({})
  res.render("home",
    {
      user: req.user,
      blogs: alllBlogs
    });
});

app.use("/user", userRouter);
app.use("/blog", blogRouter);

app.listen(PORT, () => console.log(`Server started at PORT: ${PORT}`));
