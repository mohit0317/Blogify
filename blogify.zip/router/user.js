const express = require("express");
const User = require("../model/user");

const router = express.Router();

router.get("/signup", (req, res) => {
    return res.render("signup");
});

router.post("/signup", async (req, res) => {
    const { fullName, email, password } = req.body;
  const data =   await User.create({
        fullName,
        email,
        password,
    });
    // console.log('data',data);
    return res.render("signin");
});

router.get("/signin", (req, res) => {
    return res.render("signin");
});

router.post("/signin", async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(400).send("User not found");
        }

        const token = user.verify(password);
        if (!token) {
            return res.render('signin');
        }

        return res.cookie('token', token).redirect('/');

    } catch (error) {
        console.log("Error", error);
        return res.status(500).send("Internal Server Error");
    }
});

router.get('/logout', (req, res) => {
    res.clearCookie('token').render('signin');
})

module.exports = router;
