const mongoose = require("mongoose");
const { createHmac, randomBytes } = require('crypto');
const { createTokenForUser } = require("../services/authentication");

const userSchema = new mongoose.Schema({
  fullName: {
    type: String,
    require: true
  },
  email: {
    type: String,
    require: true,
    unique: true
  },
  salt: {
    type: String,
    require: true,
  },
  password: {
    type: String,
    require: true,
    unique: true
  },
  profileImageURL: {
    type: String,
    default: '/images/images.png'
  },
  role: {
    type: String,
    enum: ['USER', "ADMIN"],
    default: "USER",
  },

}, { timestamps: true });

userSchema.pre('save', function (next) {
  const user = this;

  if (!user.isModified('password')) return;

  const salt = randomBytes(16).toString();

  const hashedPassword = createHmac('sha256', salt)
    .update(user.password).digest('hex')

  this.salt = salt;
  this.password = hashedPassword;

  next();
})

userSchema.methods.verify = function (password) {
  const hashedPassword = createHmac('sha256', this.salt)
    .update(password)
    .digest('hex');
    console.log('password !== hashedPassword',password,hashedPassword);

  if (this.password !== hashedPassword) {
    return false;
    // throw new Error('Incorrect password');
  }
// console.log('this',this);
  const token = createTokenForUser(this);
  return token;
};

const User = mongoose.model('user', userSchema);

module.exports = User;
